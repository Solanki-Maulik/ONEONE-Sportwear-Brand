# STRIDE — Animations, real add-to-cart, per-size stock, clothing sizes

## Animations (GSAP-powered)
- **Login page**: the card pops in with a scale animation, then the fields and
  button cascade in one after another. Replays automatically when you flip
  between Login and Register.
- **Product cards**: bounce/pop in as you scroll down the page (Home, Men, Women),
  using GSAP ScrollTrigger with a springy `back.out` ease.
- Everything else — layout, colors, type, the rest of the site — is unchanged,
  as asked.

## Real "Add to Cart", not "Select size"
Shop grid cards (Home/Men/Women) now show inline size chips directly on the card
plus an actual **Add to Cart** button — no more navigating away to the product
page just to pick a size. Products without sizes keep the plain one-click button.

## Per-size stock (the actual fix you asked for)
Stock used to be one number for the whole product, which doesn't work once
different sizes sell differently. Now:
- Each size has its **own stock count**, set by admin per size.
- A size with 0 stock shows as a disabled, struck-through chip — still visible,
  just not selectable.
- Quantity is capped against that specific size's stock, both when adding to
  cart and again at checkout.
- Placing an order decrements the stock for that exact size, not the whole
  product.
- The product's overall "in stock" number (shown on cards, used in admin lists)
  is automatically the sum of all its sizes' stock.

## Clothing sizes (tops/bottoms), not just shoe sizes
Admin → Add Product now has two separate size groups: **Footwear (UK 6–10)** and
**Clothing (XS–XXL)**. Check whichever sizes apply to that specific product and
set stock for each — works for shoes and for tops/bottoms in the same form. A
product with neither checked falls back to a single plain stock number, for
things that don't need sizing at all.

## Setup (XAMPP, local)
1. Copy `sports_wear` into `htdocs/`.
2. In phpMyAdmin, create an empty database first (New -> name it, e.g. `sportswear`).
3. Click on that database, then Import -> choose `stride_sportswear.sql` -> Go.
4. Check `db.php` matches your database name (default: `localhost` / `root` / no password).
5. Visit `index.php`. (The bounce/login animations need an internet connection,
   since GSAP loads from a CDN — same as the Google Fonts already in use.)

Admin login: `admin@gmail.com` / `admin123`

## Setup (InfinityFree or other shared hosting)
Free hosts pre-create exactly one database for you and never let your DB user
run `CREATE DATABASE` — that's what the `#1044 Access denied` error means if
you see it. Steps:
1. In your hosting control panel, find your existing database name — on
   InfinityFree it looks like `if0_XXXXXXX_something`.
2. In phpMyAdmin, click that database name in the left sidebar FIRST, then
   go to the Import tab and choose `stride_sportswear.sql`. Importing this
   way runs every `CREATE TABLE` inside your existing database instead of
   trying to make a new one.
3. Update `db.php` with your host's real MySQL details — shared hosting is
   almost never `localhost`:
   ```php
   $conn = new mysqli("sqlXXX.infinityfree.com", "if0_XXXXXXX", "your_db_password", "if0_XXXXXXX_dbname");
   ```
   Find the exact hostname/username/password in your hosting control panel's
   MySQL Databases section — InfinityFree shows all four right there.

## If you're patching an existing database instead of reimporting
```sql
ALTER TABLE product_sizes ADD COLUMN stock INT NOT NULL DEFAULT 0;
```
Existing size rows will start at 0 stock — go into Manage Products (or directly
in phpMyAdmin) and set real numbers for each size after running this.
