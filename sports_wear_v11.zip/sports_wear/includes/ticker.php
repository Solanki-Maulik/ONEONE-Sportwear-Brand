<?php
$__brand_t = isset($settings) ? setting($settings, 'site_name', 'STRIDE') : 'STRIDE';
$__ticker = [
    isset($settings) ? setting($settings, 'ticker_1', 'Free shipping over ₹2,000') : 'Free shipping over ₹2,000',
    isset($settings) ? setting($settings, 'ticker_2', 'New drop every friday') : 'New drop every friday',
    isset($settings) ? setting($settings, 'ticker_3', 'Easy 30-day returns') : 'Easy 30-day returns',
    isset($settings) ? setting($settings, 'ticker_4', 'Train with ' . $__brand_t) : 'Train with ' . $__brand_t,
];
?>
    <div class="ticker">
        <div class="ticker-track">
            <?php for ($i = 0; $i < 2; $i++): foreach ($__ticker as $msg): ?>
                <span><?php echo htmlspecialchars($msg); ?></span>
            <?php endforeach; endfor; ?>
        </div>
    </div>
