<?php
// Site-wide editable settings (theme colors, hero content, images, copy).
// Backed by the `site_settings` key/value table. Admin edits these from
// admin/site_settings.php; every customer-facing page reads them here with
// sensible hardcoded fallbacks, so the site still looks right even if a
// setting was never set (or was cleared via "Reset to defaults").

function get_settings($conn) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $result = $conn->query("SELECT setting_key, setting_value FROM site_settings");
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        }
    }
    return $cache;
}

function setting($settings, $key, $default = '') {
    return (isset($settings[$key]) && $settings[$key] !== '') ? $settings[$key] : $default;
}

// Prints a small inline <style> block that overrides the CSS custom
// properties defined in style.css / login.css, so admin-picked theme
// colors apply site-wide without editing the stylesheet files themselves.
function render_theme_vars($settings) {
    $accent = setting($settings, 'theme_accent', '#FF4D23');
    $ink    = setting($settings, 'theme_ink', '#10131A');
    echo "<style>:root{--accent:" . htmlspecialchars($accent) . ";--ink:" . htmlspecialchars($ink) . ";}</style>\n";
}
