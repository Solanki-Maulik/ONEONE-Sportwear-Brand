<?php
// Shared on every page: starts the session and prepares the cart array.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

function cart_count() {
    $count = 0;
    foreach ($_SESSION['cart'] as $qty) {
        // Defensive: ignore any malformed/non-numeric entry instead of fatally erroring.
        if (is_numeric($qty)) {
            $count += (int)$qty;
        }
    }
    return $count;
}
?>
