<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
require '../db.php';
require '../includes/settings.php';

$fields = [
    'site_name'          => 'Brand name (shown in nav, footer, browser title)',
    'theme_accent'        => 'Accent color',
    'theme_ink'           => 'Dark/ink color (nav, hero, footer)',
    'hero_headline'       => 'Hero headline (an HTML <br> is allowed for a line break)',
    'hero_subtext'        => 'Hero subheading text',
    'hero_image_1'        => 'Hero carousel image 1 (URL or img/... path)',
    'hero_image_2'        => 'Hero carousel image 2',
    'hero_image_3'        => 'Hero carousel image 3',
    'hero_image_4'        => 'Hero carousel image 4',
    'category_men_label'  => 'Men category tile label',
    'category_men_image'  => 'Men category tile image (URL or img/... path)',
    'category_women_label'=> 'Women category tile label',
    'category_women_image'=> 'Women category tile image (URL or img/... path)',
    'ticker_1'             => 'Promo ticker message 1',
    'ticker_2'             => 'Promo ticker message 2',
    'ticker_3'             => 'Promo ticker message 3',
    'ticker_4'             => 'Promo ticker message 4',
    'footer_blurb'         => 'Footer brand blurb',
];

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reset_defaults'])) {
        $conn->query("DELETE FROM site_settings");
        $message = "All settings reset to defaults.";
    } else {
        $stmt = $conn->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        foreach ($fields as $key => $label) {
            $value = isset($_POST[$key]) ? trim($_POST[$key]) : '';
            $stmt->bind_param("ss", $key, $value);
            $stmt->execute();
        }
        $stmt->close();
        $message = "Settings saved. Refresh the storefront to see the changes.";
    }
}

// Re-read after any save/reset so the form shows current values.
$result = $conn->query("SELECT setting_key, setting_value FROM site_settings");
$current = [];
while ($row = $result->fetch_assoc()) { $current[$row['setting_key']] = $row['setting_value']; }
function cur($current, $key, $default = '') {
    return isset($current[$key]) && $current[$key] !== '' ? $current[$key] : $default;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Site Settings - Sportswear Elite</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; display: flex; background: #f4f7f6; color: #333; }
        .sidebar { width: 250px; background: #111; color: white; min-height: 100vh; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { color: #fff; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; }
        .sidebar a { color: #aaa; text-decoration: none; display: block; padding: 12px 10px; margin-bottom: 5px; border-radius: 4px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: #333; color: #f39c12; }
        .sidebar .logout { color: #e74c3c; margin-top: 30px; }
        .sidebar .logout:hover { background: #e74c3c; color: white; }
        .content { flex: 1; padding: 30px 40px; max-width: 820px; }
        .content h1 { margin-top: 0; }
        .card { background: white; border-radius: 10px; padding: 26px 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.06); margin-bottom: 24px; }
        .card h3 { margin-top: 0; text-transform: uppercase; font-size: 13px; letter-spacing: 1px; color: #888; }
        label.field-label { display: block; font-size: 13px; font-weight: 600; margin: 14px 0 6px; color: #444; }
        input[type=text], textarea { width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; box-sizing: border-box; font-family: inherit; }
        input[type=color] { width: 60px; height: 36px; border: 1px solid #ddd; border-radius: 6px; padding: 2px; cursor: pointer; }
        textarea { min-height: 60px; resize: vertical; }
        .row2 { display: flex; gap: 20px; flex-wrap: wrap; }
        .row2 > div { flex: 1; min-width: 200px; }
        .save-btn { background: #f39c12; color: white; border: none; padding: 13px 30px; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px; margin-top: 10px; }
        .save-btn:hover { background: #d98607; }
        .reset-btn { background: #eee; color: #c0392b; border: 1px solid #ddd; padding: 13px 24px; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px; margin-top: 10px; margin-left: 10px; }
        .reset-btn:hover { background: #f7d7d2; }
        .message { background: #eafaf1; color: #1e8449; padding: 12px 18px; border-radius: 8px; margin-bottom: 20px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="dashboard.php">📊 Dashboard</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="manage_products.php">📦 Manage Products</a>
        <a href="manage_orders.php">🛒 Manage Orders</a>
        <a href="coupons.php">🎟️ Coupons</a>
        <a href="site_settings.php" class="active">🎨 Site Settings</a>
        <a href="../logout.php" class="logout">🚪 Logout</a>
    </div>

    <div class="content">
        <h1>Site Settings</h1>
        <p style="color:#666;">Edit the storefront's theme, hero content, and images without touching any code. Leave a field blank to fall back to the site default. You can always come back and reset everything if you want to remove this later.</p>

        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="card">
                <h3>Theme</h3>
                <div class="row2">
                    <div>
                        <label class="field-label">Brand name</label>
                        <input type="text" name="site_name" value="<?php echo htmlspecialchars(cur($current, 'site_name', 'STRIDE')); ?>">
                    </div>
                    <div>
                        <label class="field-label">Accent color</label>
                        <input type="color" name="theme_accent" value="<?php echo htmlspecialchars(cur($current, 'theme_accent', '#FF4D23')); ?>">
                    </div>
                    <div>
                        <label class="field-label">Dark / ink color</label>
                        <input type="color" name="theme_ink" value="<?php echo htmlspecialchars(cur($current, 'theme_ink', '#10131A')); ?>">
                    </div>
                </div>
            </div>

            <div class="card">
                <h3>Hero section</h3>
                <label class="field-label">Headline (an HTML &lt;br&gt; is allowed for a manual line break)</label>
                <input type="text" name="hero_headline" value="<?php echo htmlspecialchars(cur($current, 'hero_headline', 'Move like<br>you mean it.')); ?>">
                <label class="field-label">Subheading</label>
                <textarea name="hero_subtext"><?php echo htmlspecialchars(cur($current, 'hero_subtext', "Footwear and jerseys engineered for people who train hard and don't stop at good enough. Built for the run, the court, and everything after.")); ?></textarea>
                <label class="field-label">Carousel images (rotates automatically, one every ~4 seconds)</label>
                <div class="row2">
                    <div><input type="text" name="hero_image_1" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'hero_image_1')); ?>"></div>
                    <div><input type="text" name="hero_image_2" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'hero_image_2')); ?>"></div>
                </div>
                <div class="row2" style="margin-top:8px;">
                    <div><input type="text" name="hero_image_3" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'hero_image_3')); ?>"></div>
                    <div><input type="text" name="hero_image_4" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'hero_image_4')); ?>"></div>
                </div>
            </div>

            <div class="card">
                <h3>Category tiles</h3>
                <div class="row2">
                    <div>
                        <label class="field-label">Men tile label</label>
                        <input type="text" name="category_men_label" value="<?php echo htmlspecialchars(cur($current, 'category_men_label', 'Men')); ?>">
                        <label class="field-label">Men tile image</label>
                        <input type="text" name="category_men_image" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'category_men_image')); ?>">
                    </div>
                    <div>
                        <label class="field-label">Women tile label</label>
                        <input type="text" name="category_women_label" value="<?php echo htmlspecialchars(cur($current, 'category_women_label', 'Women')); ?>">
                        <label class="field-label">Women tile image</label>
                        <input type="text" name="category_women_image" placeholder="img/... or https://..." value="<?php echo htmlspecialchars(cur($current, 'category_women_image')); ?>">
                    </div>
                </div>
            </div>

            <div class="card">
                <h3>Promo ticker</h3>
                <div class="row2">
                    <div><input type="text" name="ticker_1" value="<?php echo htmlspecialchars(cur($current, 'ticker_1', 'Free shipping over ₹2,000')); ?>"></div>
                    <div><input type="text" name="ticker_2" value="<?php echo htmlspecialchars(cur($current, 'ticker_2', 'New drop every friday')); ?>"></div>
                </div>
                <div class="row2" style="margin-top:8px;">
                    <div><input type="text" name="ticker_3" value="<?php echo htmlspecialchars(cur($current, 'ticker_3', 'Easy 30-day returns')); ?>"></div>
                    <div><input type="text" name="ticker_4" value="<?php echo htmlspecialchars(cur($current, 'ticker_4', 'Train with STRIDE')); ?>"></div>
                </div>
            </div>

            <div class="card">
                <h3>Footer</h3>
                <label class="field-label">Brand blurb</label>
                <textarea name="footer_blurb"><?php echo htmlspecialchars(cur($current, 'footer_blurb', 'Performance sportswear built for the run, the court, and everything after. Designed and tested by people who actually train.')); ?></textarea>
            </div>

            <button type="submit" class="save-btn">Save changes</button>
            <button type="submit" name="reset_defaults" value="1" class="reset-btn" onclick="return confirm('Reset every setting back to the site defaults?');">Reset to defaults</button>
        </form>
    </div>
</body>
</html>
